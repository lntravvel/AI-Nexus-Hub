
const fs = require('fs');
const content = fs.readFileSync('src/data.ts', 'utf8');

const toolBlocks = content.split(/\{\s*id:/).slice(1);
toolBlocks.forEach(block => {
    const idMatch = block.match(/'([^']+)'/);
    if (idMatch) {
        const id = idMatch[1];
        if (!block.includes('url:')) {
            console.log(`Tool ${id} is missing url`);
        }
    }
});
